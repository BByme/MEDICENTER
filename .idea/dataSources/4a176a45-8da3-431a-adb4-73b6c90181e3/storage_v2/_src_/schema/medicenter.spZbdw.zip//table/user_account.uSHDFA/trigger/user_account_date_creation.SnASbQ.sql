create trigger user_account_date_creation
  before INSERT
  on user_account
  for each row
  set NEW.Creation_time = now();

