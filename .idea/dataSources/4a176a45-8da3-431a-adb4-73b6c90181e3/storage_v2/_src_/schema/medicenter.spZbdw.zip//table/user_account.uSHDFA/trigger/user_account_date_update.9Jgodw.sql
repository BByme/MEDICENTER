create trigger user_account_date_update
  before UPDATE
  on user_account
  for each row
  set NEW.update_time = now();

